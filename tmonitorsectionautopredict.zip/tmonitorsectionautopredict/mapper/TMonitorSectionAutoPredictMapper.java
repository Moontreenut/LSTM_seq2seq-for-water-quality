/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.modules.datamanager.tmonitorsectionautopredict.mapper;

import com.jeeplus.modules.datamanager.tmonitorsectionauto.entity.TMonitorSectionAutoApps;
import org.springframework.stereotype.Repository;
import com.jeeplus.core.persistence.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import com.jeeplus.modules.datamanager.tmonitorsectionautopredict.entity.TMonitorSectionAutoPredict;

import java.util.List;

/**
 * 水质自动站预测信息MAPPER接口
 * @author liu
 * @version 2021-09-08
 */
@Mapper
@Repository
public interface TMonitorSectionAutoPredictMapper extends BaseMapper<TMonitorSectionAutoPredict> {

    public List<TMonitorSectionAutoApps> findWl7rszzyc(TMonitorSectionAutoApps tMonitorSectionAutoApps);
	
}