/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.modules.datamanager.tmonitorsectionautopredict.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;

import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;
import com.jeeplus.common.utils.DateUtils;
import com.jeeplus.common.json.AjaxJson;
import com.jeeplus.core.persistence.Page;
import com.jeeplus.core.web.BaseController;
import com.jeeplus.common.utils.StringUtils;
import com.jeeplus.common.utils.excel.ExportExcel;
import com.jeeplus.common.utils.excel.ImportExcel;
import com.jeeplus.modules.datamanager.tmonitorsectionautopredict.entity.TMonitorSectionAutoPredict;
import com.jeeplus.modules.datamanager.tmonitorsectionautopredict.service.TMonitorSectionAutoPredictService;

/**
 * 水质自动站预测信息Controller
 * @author liu
 * @version 2021-09-08
 */
@Controller
@RequestMapping(value = "${adminPath}/datamanager/tmonitorsectionautopredict/tMonitorSectionAutoPredict")
public class TMonitorSectionAutoPredictController extends BaseController {

	@Autowired
	private TMonitorSectionAutoPredictService tMonitorSectionAutoPredictService;
	
	@ModelAttribute
	public TMonitorSectionAutoPredict get(@RequestParam(required=false) String id) {
		TMonitorSectionAutoPredict entity = null;
		if (StringUtils.isNotBlank(id)){
			entity = tMonitorSectionAutoPredictService.get(id);
		}
		if (entity == null){
			entity = new TMonitorSectionAutoPredict();
		}
		return entity;
	}
	
	/**
	 * 水质自动站预测信息列表页面
	 */
	@RequiresPermissions("datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:list")
	@RequestMapping(value = {"list", ""})
	public String list(TMonitorSectionAutoPredict tMonitorSectionAutoPredict, Model model) {
		model.addAttribute("tMonitorSectionAutoPredict", tMonitorSectionAutoPredict);
		return "modules/datamanager/tmonitorsectionautopredict/tMonitorSectionAutoPredictList";
	}
	
		/**
	 * 水质自动站预测信息列表数据
	 */
	@ResponseBody
	@RequiresPermissions("datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:list")
	@RequestMapping(value = "data")
	public Map<String, Object> data(TMonitorSectionAutoPredict tMonitorSectionAutoPredict, HttpServletRequest request, HttpServletResponse response, Model model) {
		Page<TMonitorSectionAutoPredict> page = tMonitorSectionAutoPredictService.findPage(new Page<TMonitorSectionAutoPredict>(request, response), tMonitorSectionAutoPredict); 
		return getBootstrapData(page);
	}

	/**
	 * 查看，增加，编辑水质自动站预测信息表单页面
	 * params:
	 * 	mode: add, edit, view, 代表三种模式的页面
	 */
	@RequiresPermissions(value={"datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:view","datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:add","datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:edit"},logical=Logical.OR)
	@RequestMapping(value = "form/{mode}")
	public String form(@PathVariable String mode, TMonitorSectionAutoPredict tMonitorSectionAutoPredict, Model model) {
		model.addAttribute("mode", mode);
		model.addAttribute("tMonitorSectionAutoPredict", tMonitorSectionAutoPredict);
		return "modules/datamanager/tmonitorsectionautopredict/tMonitorSectionAutoPredictForm";
	}

	/**
	 * 保存水质自动站预测信息
	 */
	@ResponseBody
	@RequiresPermissions(value={"datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:add","datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:edit"},logical=Logical.OR)
	@RequestMapping(value = "save")
	public AjaxJson save(TMonitorSectionAutoPredict tMonitorSectionAutoPredict, Model model) throws Exception{
		AjaxJson j = new AjaxJson();
		/**
		 * 后台hibernate-validation插件校验
		 */
		String errMsg = beanValidator(tMonitorSectionAutoPredict);
		if (StringUtils.isNotBlank(errMsg)){
			j.setSuccess(false);
			j.setMsg(errMsg);
			return j;
		}
		//新增或编辑表单保存
		tMonitorSectionAutoPredictService.save(tMonitorSectionAutoPredict);//保存
		j.setSuccess(true);
		j.setMsg("保存水质自动站预测信息成功");
		return j;
	}

	
	/**
	 * 批量删除水质自动站预测信息
	 */
	@ResponseBody
	@RequiresPermissions("datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:del")
	@RequestMapping(value = "delete")
	public AjaxJson delete(String ids) {
		AjaxJson j = new AjaxJson();
		String idArray[] =ids.split(",");
		for(String id : idArray){
			tMonitorSectionAutoPredictService.delete(tMonitorSectionAutoPredictService.get(id));
		}
		j.setMsg("删除水质自动站预测信息成功");
		return j;
	}
	
	/**
	 * 导出excel文件
	 */
	@ResponseBody
	@RequiresPermissions("datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:export")
    @RequestMapping(value = "export")
    public AjaxJson exportFile(TMonitorSectionAutoPredict tMonitorSectionAutoPredict, HttpServletRequest request, HttpServletResponse response) {
		AjaxJson j = new AjaxJson();
		try {
            String fileName = "水质自动站预测信息"+DateUtils.getDate("yyyyMMddHHmmss")+".xlsx";
            Page<TMonitorSectionAutoPredict> page = tMonitorSectionAutoPredictService.findPage(new Page<TMonitorSectionAutoPredict>(request, response, -1), tMonitorSectionAutoPredict);
    		new ExportExcel("水质自动站预测信息", TMonitorSectionAutoPredict.class).setDataList(page.getList()).write(response, fileName).dispose();
    		return null;
		} catch (Exception e) {
			j.setSuccess(false);
			j.setMsg("导出水质自动站预测信息记录失败！失败信息："+e.getMessage());
		}
			return j;
    }

	/**
	 * 导入Excel数据

	 */
	@ResponseBody
	@RequiresPermissions("datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:import")
    @RequestMapping(value = "import")
   	public AjaxJson importFile(@RequestParam("file")MultipartFile file, HttpServletResponse response, HttpServletRequest request) {
		AjaxJson j = new AjaxJson();
		try {
			int successNum = 0;
			int failureNum = 0;
			StringBuilder failureMsg = new StringBuilder();
			ImportExcel ei = new ImportExcel(file, 1, 0);
			List<TMonitorSectionAutoPredict> list = ei.getDataList(TMonitorSectionAutoPredict.class);
			for (TMonitorSectionAutoPredict tMonitorSectionAutoPredict : list){
				try{
					tMonitorSectionAutoPredictService.save(tMonitorSectionAutoPredict);
					successNum++;
				}catch(ConstraintViolationException ex){
					failureNum++;
				}catch (Exception ex) {
					failureNum++;
				}
			}
			if (failureNum>0){
				failureMsg.insert(0, "，失败 "+failureNum+" 条水质自动站预测信息记录。");
			}
			j.setMsg( "已成功导入 "+successNum+" 条水质自动站预测信息记录"+failureMsg);
		} catch (Exception e) {
			j.setSuccess(false);
			j.setMsg("导入水质自动站预测信息失败！失败信息："+e.getMessage());
		}
		return j;
    }
	
	/**
	 * 下载导入水质自动站预测信息数据模板
	 */
	@ResponseBody
	@RequiresPermissions("datamanager:tmonitorsectionautopredict:tMonitorSectionAutoPredict:import")
    @RequestMapping(value = "import/template")
     public AjaxJson importFileTemplate(HttpServletResponse response) {
		AjaxJson j = new AjaxJson();
		try {
            String fileName = "水质自动站预测信息数据导入模板.xlsx";
    		List<TMonitorSectionAutoPredict> list = Lists.newArrayList(); 
    		new ExportExcel("水质自动站预测信息数据", TMonitorSectionAutoPredict.class, 1).setDataList(list).write(response, fileName).dispose();
    		return null;
		} catch (Exception e) {
			j.setSuccess(false);
			j.setMsg( "导入模板下载失败！失败信息："+e.getMessage());
		}
		return j;
    }

}