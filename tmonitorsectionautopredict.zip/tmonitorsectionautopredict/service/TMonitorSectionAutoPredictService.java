/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.modules.datamanager.tmonitorsectionautopredict.service;

import java.util.List;

import com.jeeplus.modules.datamanager.tmonitorsectionauto.entity.TMonitorSectionAutoApps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jeeplus.core.persistence.Page;
import com.jeeplus.core.service.CrudService;
import com.jeeplus.database.datasource.annotation.DS;
import com.jeeplus.modules.datamanager.tmonitorsectionautopredict.entity.TMonitorSectionAutoPredict;
import com.jeeplus.modules.datamanager.tmonitorsectionautopredict.mapper.TMonitorSectionAutoPredictMapper;

/**
 * 水质自动站预测信息Service
 * @author liu
 * @version 2021-09-08
 */
@DS("hslyDb")
@Service
@Transactional(readOnly = true)
public class TMonitorSectionAutoPredictService extends CrudService<TMonitorSectionAutoPredictMapper, TMonitorSectionAutoPredict> {

	@Autowired
	private TMonitorSectionAutoPredictMapper tMonitorSectionAutoPredictMapper;

	public TMonitorSectionAutoPredict get(String id) {
		return super.get(id);
	}
	
	public List<TMonitorSectionAutoPredict> findList(TMonitorSectionAutoPredict tMonitorSectionAutoPredict) {
		return super.findList(tMonitorSectionAutoPredict);
	}
	
	public Page<TMonitorSectionAutoPredict> findPage(Page<TMonitorSectionAutoPredict> page, TMonitorSectionAutoPredict tMonitorSectionAutoPredict) {
		return super.findPage(page, tMonitorSectionAutoPredict);
	}
	
	@Transactional(readOnly = false)
	public void save(TMonitorSectionAutoPredict tMonitorSectionAutoPredict) {
		super.save(tMonitorSectionAutoPredict);
	}
	
	@Transactional(readOnly = false)
	public void delete(TMonitorSectionAutoPredict tMonitorSectionAutoPredict) {
		super.delete(tMonitorSectionAutoPredict);
	}

	public List<TMonitorSectionAutoApps> findWl7rszzyc(TMonitorSectionAutoApps tMonitorSectionAutoApps){
		return tMonitorSectionAutoPredictMapper.findWl7rszzyc(tMonitorSectionAutoApps);
	}
	
}