/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.modules.datamanager.tmonitorsectionautopredict.entity;


import com.jeeplus.core.persistence.DataEntity;
import com.jeeplus.common.utils.excel.annotation.ExcelField;

/**
 * 水质自动站预测信息Entity
 * @author liu
 * @version 2021-09-08
 */
public class TMonitorSectionAutoPredict extends DataEntity<TMonitorSectionAutoPredict> {
	
	private static final long serialVersionUID = 1L;
	private String baseStartTime;		// 基准时间-起
	private String baseEndTime;		// 基准时间-止
	private String executeTime;		// 模型执行时间
	private String predictTime;		// 时间
	private String sectionCode;		// 断面编码
	private String sectionName;		// 断面名称
	private String waterStatus;		// 水质类别
	private String isStandards;		// 是否达标
	private String excessiveFactor;		// 超标因子(倍数)
	private String waterTemperature;		// 水温(℃)
	private String waterTemperature1;		// 水温超标倍数
	private String waterTemperature2;		// 水文水质类别
	private String phValue;		// PH值
	private String phValue1;		// PH值超标倍数
	private String phValue2;		// PH值水质类别
	private String dissolvedOxygen;		// 溶解氧(mg/L)
	private String dissolvedOxygen1;		// 溶解氧超标倍数
	private String dissolvedOxygen2;		// 溶解氧水质类别
	private String conductivity;		// 电导率(μS/cm)
	private String conductivity1;		// 电导率超标倍数
	private String conductivity2;		// 电导率水质类别
	private String turbidity;		// 浊度(NTU)
	private String turbidity1;		// 浊度超标倍数
	private String turbidity2;		// 浊度水质类别
	private String permanganateIndex;		// 高锰酸盐指数(mg/L)
	private String permanganateIndex1;		// 高锰酸盐指数超标倍数
	private String permanganateIndex2;		// 高锰酸盐指数水质类别
	private String ammonia;		// 氨氮(mg/L)
	private String ammonia1;		// 氨氮超标倍数
	private String ammonia2;		// 氨氮水质类别
	private String totalPhosphorus;		// 总磷(mg/L)
	private String totalPhosphorus1;		// 总磷超标倍数
	private String totalPhosphorus2;		// 总磷水质类别
	private String totalNitrogen;		// 总氮(mg/L)
	private String totalNitrogen1;		// 总氮超标倍数
	private String totalNitrogen2;		// 总氮水质类别
	private String beginExecuteTime;		// 开始 模型执行时间
	private String endExecuteTime;		// 结束 模型执行时间
	
	public TMonitorSectionAutoPredict() {
		super();
		this.setIdType(IDTYPE_AUTO);
	}

	public TMonitorSectionAutoPredict(String id){
		super(id);
	}

	@ExcelField(title="基准时间-起", align=2, sort=1)
	public String getBaseStartTime() {
		return baseStartTime;
	}

	public void setBaseStartTime(String baseStartTime) {
		this.baseStartTime = baseStartTime;
	}
	
	@ExcelField(title="基准时间-止", align=2, sort=2)
	public String getBaseEndTime() {
		return baseEndTime;
	}

	public void setBaseEndTime(String baseEndTime) {
		this.baseEndTime = baseEndTime;
	}
	
	@ExcelField(title="模型执行时间", align=2, sort=3)
	public String getExecuteTime() {
		return executeTime;
	}

	public void setExecuteTime(String executeTime) {
		this.executeTime = executeTime;
	}
	
	@ExcelField(title="时间", align=2, sort=4)
	public String getPredictTime() {
		return predictTime;
	}

	public void setPredictTime(String predictTime) {
		this.predictTime = predictTime;
	}
	
	@ExcelField(title="断面编码", align=2, sort=5)
	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}
	
	@ExcelField(title="断面名称", align=2, sort=6)
	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	@ExcelField(title="水质类别", dictType="水质类别", align=2, sort=7)
	public String getWaterStatus() {
		return waterStatus;
	}

	public void setWaterStatus(String waterStatus) {
		this.waterStatus = waterStatus;
	}
	
	@ExcelField(title="是否达标", align=2, sort=8)
	public String getIsStandards() {
		return isStandards;
	}

	public void setIsStandards(String isStandards) {
		this.isStandards = isStandards;
	}
	
	@ExcelField(title="超标因子(倍数)", align=2, sort=9)
	public String getExcessiveFactor() {
		return excessiveFactor;
	}

	public void setExcessiveFactor(String excessiveFactor) {
		this.excessiveFactor = excessiveFactor;
	}
	
	@ExcelField(title="水温(℃)", align=2, sort=10)
	public String getWaterTemperature() {
		return waterTemperature;
	}

	public void setWaterTemperature(String waterTemperature) {
		this.waterTemperature = waterTemperature;
	}
	
	@ExcelField(title="水温超标倍数", align=2, sort=11)
	public String getWaterTemperature1() {
		return waterTemperature1;
	}

	public void setWaterTemperature1(String waterTemperature1) {
		this.waterTemperature1 = waterTemperature1;
	}
	
	@ExcelField(title="水文水质类别", dictType="水质类别", align=2, sort=12)
	public String getWaterTemperature2() {
		return waterTemperature2;
	}

	public void setWaterTemperature2(String waterTemperature2) {
		this.waterTemperature2 = waterTemperature2;
	}
	
	@ExcelField(title="PH值", align=2, sort=13)
	public String getPhValue() {
		return phValue;
	}

	public void setPhValue(String phValue) {
		this.phValue = phValue;
	}
	
	@ExcelField(title="PH值超标倍数", align=2, sort=14)
	public String getPhValue1() {
		return phValue1;
	}

	public void setPhValue1(String phValue1) {
		this.phValue1 = phValue1;
	}
	
	@ExcelField(title="PH值水质类别", dictType="水质类别", align=2, sort=15)
	public String getPhValue2() {
		return phValue2;
	}

	public void setPhValue2(String phValue2) {
		this.phValue2 = phValue2;
	}
	
	@ExcelField(title="溶解氧(mg/L)", align=2, sort=16)
	public String getDissolvedOxygen() {
		return dissolvedOxygen;
	}

	public void setDissolvedOxygen(String dissolvedOxygen) {
		this.dissolvedOxygen = dissolvedOxygen;
	}
	
	@ExcelField(title="溶解氧超标倍数", align=2, sort=17)
	public String getDissolvedOxygen1() {
		return dissolvedOxygen1;
	}

	public void setDissolvedOxygen1(String dissolvedOxygen1) {
		this.dissolvedOxygen1 = dissolvedOxygen1;
	}
	
	@ExcelField(title="溶解氧水质类别", dictType="水质类别", align=2, sort=18)
	public String getDissolvedOxygen2() {
		return dissolvedOxygen2;
	}

	public void setDissolvedOxygen2(String dissolvedOxygen2) {
		this.dissolvedOxygen2 = dissolvedOxygen2;
	}
	
	@ExcelField(title="电导率(μS/cm)", align=2, sort=19)
	public String getConductivity() {
		return conductivity;
	}

	public void setConductivity(String conductivity) {
		this.conductivity = conductivity;
	}
	
	@ExcelField(title="电导率超标倍数", align=2, sort=20)
	public String getConductivity1() {
		return conductivity1;
	}

	public void setConductivity1(String conductivity1) {
		this.conductivity1 = conductivity1;
	}
	
	@ExcelField(title="电导率水质类别", dictType="水质类别", align=2, sort=21)
	public String getConductivity2() {
		return conductivity2;
	}

	public void setConductivity2(String conductivity2) {
		this.conductivity2 = conductivity2;
	}
	
	@ExcelField(title="浊度(NTU)", align=2, sort=22)
	public String getTurbidity() {
		return turbidity;
	}

	public void setTurbidity(String turbidity) {
		this.turbidity = turbidity;
	}
	
	@ExcelField(title="浊度超标倍数", align=2, sort=23)
	public String getTurbidity1() {
		return turbidity1;
	}

	public void setTurbidity1(String turbidity1) {
		this.turbidity1 = turbidity1;
	}
	
	@ExcelField(title="浊度水质类别", dictType="水质类别", align=2, sort=24)
	public String getTurbidity2() {
		return turbidity2;
	}

	public void setTurbidity2(String turbidity2) {
		this.turbidity2 = turbidity2;
	}
	
	@ExcelField(title="高锰酸盐指数(mg/L)", align=2, sort=25)
	public String getPermanganateIndex() {
		return permanganateIndex;
	}

	public void setPermanganateIndex(String permanganateIndex) {
		this.permanganateIndex = permanganateIndex;
	}
	
	@ExcelField(title="高锰酸盐指数超标倍数", align=2, sort=26)
	public String getPermanganateIndex1() {
		return permanganateIndex1;
	}

	public void setPermanganateIndex1(String permanganateIndex1) {
		this.permanganateIndex1 = permanganateIndex1;
	}
	
	@ExcelField(title="高锰酸盐指数水质类别", dictType="水质类别", align=2, sort=27)
	public String getPermanganateIndex2() {
		return permanganateIndex2;
	}

	public void setPermanganateIndex2(String permanganateIndex2) {
		this.permanganateIndex2 = permanganateIndex2;
	}
	
	@ExcelField(title="氨氮(mg/L)", align=2, sort=28)
	public String getAmmonia() {
		return ammonia;
	}

	public void setAmmonia(String ammonia) {
		this.ammonia = ammonia;
	}
	
	@ExcelField(title="氨氮超标倍数", align=2, sort=29)
	public String getAmmonia1() {
		return ammonia1;
	}

	public void setAmmonia1(String ammonia1) {
		this.ammonia1 = ammonia1;
	}
	
	@ExcelField(title="氨氮水质类别", dictType="水质类别", align=2, sort=30)
	public String getAmmonia2() {
		return ammonia2;
	}

	public void setAmmonia2(String ammonia2) {
		this.ammonia2 = ammonia2;
	}
	
	@ExcelField(title="总磷(mg/L)", align=2, sort=31)
	public String getTotalPhosphorus() {
		return totalPhosphorus;
	}

	public void setTotalPhosphorus(String totalPhosphorus) {
		this.totalPhosphorus = totalPhosphorus;
	}
	
	@ExcelField(title="总磷超标倍数", align=2, sort=32)
	public String getTotalPhosphorus1() {
		return totalPhosphorus1;
	}

	public void setTotalPhosphorus1(String totalPhosphorus1) {
		this.totalPhosphorus1 = totalPhosphorus1;
	}
	
	@ExcelField(title="总磷水质类别", dictType="水质类别", align=2, sort=33)
	public String getTotalPhosphorus2() {
		return totalPhosphorus2;
	}

	public void setTotalPhosphorus2(String totalPhosphorus2) {
		this.totalPhosphorus2 = totalPhosphorus2;
	}
	
	@ExcelField(title="总氮(mg/L)", align=2, sort=34)
	public String getTotalNitrogen() {
		return totalNitrogen;
	}

	public void setTotalNitrogen(String totalNitrogen) {
		this.totalNitrogen = totalNitrogen;
	}
	
	@ExcelField(title="总氮超标倍数", align=2, sort=35)
	public String getTotalNitrogen1() {
		return totalNitrogen1;
	}

	public void setTotalNitrogen1(String totalNitrogen1) {
		this.totalNitrogen1 = totalNitrogen1;
	}
	
	@ExcelField(title="总氮水质类别", dictType="水质类别", align=2, sort=36)
	public String getTotalNitrogen2() {
		return totalNitrogen2;
	}

	public void setTotalNitrogen2(String totalNitrogen2) {
		this.totalNitrogen2 = totalNitrogen2;
	}
	
	public String getBeginExecuteTime() {
		return beginExecuteTime;
	}

	public void setBeginExecuteTime(String beginExecuteTime) {
		this.beginExecuteTime = beginExecuteTime;
	}
	
	public String getEndExecuteTime() {
		return endExecuteTime;
	}

	public void setEndExecuteTime(String endExecuteTime) {
		this.endExecuteTime = endExecuteTime;
	}
		
}