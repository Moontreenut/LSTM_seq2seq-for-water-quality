// pages/yc/index.js
import * as echarts from '../../ec-canvas/echarts';

const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    echartsWeekIcon: '/image/home/echartsweekicon.png',
    index: 0,
    array : [''],
    arrayCode : [''],
    tabItems: ['水质', '氨氮', 'CODMn', '总磷', '总氮', 'PH值'],
    tabIndex: 0,
    tabIndex2: 0,
    weekSelect: false,
    allowDown: '/image/home/allowdown.png',
    allowUp: '/image/home/allowdown.png',
    ec: {
      lazyLoad: false
      //onInit: initChart
    },
    initChart1dateTimes : [],
    initChart1ammonias : [],
    initChart1permanganateIndexs : [],
    initChart1phValues : [],
    initChart1totalNitrogens : [],
    initChart1totalPhosphoruss : [],
    initChart1waterStatuss : [],
    gss : [],
    tabItems3: ['图表', '表格'],
    tabIndex3: 0,
    tabItems4: ['水质', '氨氮', 'CODMn', '总磷', '总氮', 'PH值'],
    tabIndex4: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(app.globalData.userid == null){
      this.toLogin();
      return
    }
    var that = this;
    wx.request({
      url: app.globalData.ip_api + ":" + app.globalData.port_api + '/hsApp/appInterface/yc',
      header: {
        "Content-Type": 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: function (res) {
        if(res.statusCode == 200){
          //console.log(res.data);
          that.setData({
            array : res.data.name,
            arrayCode : res.data.code,
            sectionCode : res.data.code[that.data.index],
            initChart1dateTimes : res.data.wlqrszyc.dateTimes,
            initChart1ammonias : res.data.wlqrszyc.ammonias,
            initChart1permanganateIndexs : res.data.wlqrszyc.permanganateIndexs,
            initChart1phValues : res.data.wlqrszyc.phValues,
            initChart1totalNitrogens : res.data.wlqrszyc.totalNitrogens,
            initChart1totalPhosphoruss : res.data.wlqrszyc.totalPhosphoruss,
            initChart1waterStatuss : res.data.wlqrszyc.waterStatuss,
            gss : res.data.wlqrszyc.gss,
          });
          that.initChart1();
        }else{
          //获取失败
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.echartsComponnet1 = this.selectComponent('#mychart-dom-graph')
    if (this.echartsComponnet1 != null) {
      this.initChart1()
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //七日监测下拉选
  bindPickerChange(e) {
    this.setData({
      index: e.detail.value,
      sectionCode :this.data.arrayCode[e.detail.value]
    })
    //console.log(this.data.sectionCode);
    //查询数据
    var data = {
      sectionCode : this.data.sectionCode
    }
    var that = this;
    wx.request({
      url: app.globalData.ip_api + ":" + app.globalData.port_api + '/hsApp/appInterface/ycWlqrszyc',
      header: {
        "Content-Type": 'application/x-www-form-urlencoded'
      },
      method: 'post',
      data : data,
      success: function (res) {
        if(res.statusCode == 200){
          //console.log(res.data);
          that.setData({
            initChart1dateTimes : res.data.dateTimes,
            initChart1ammonias : res.data.ammonias,
            initChart1permanganateIndexs : res.data.permanganateIndexs,
            initChart1phValues : res.data.phValues,
            initChart1totalNitrogens : res.data.totalNitrogens,
            initChart1totalPhosphoruss : res.data.totalPhosphoruss,
            initChart1waterStatuss : res.data.waterStatuss,
            gss : res.data.gss,
          });
          that.initChart1()
        }else{
          //获取失败
        }
      }
    })
  },

  changeTabs(e) {
    const tabIndex = e.currentTarget.dataset.index;
    this.setData({
      tabIndex
    })
    //console.log(this.data.tabIndex)
    this.initChart1();
  },

  changeTabs2(e) {
    const tabIndex2 = e.currentTarget.dataset.index;
    this.setData({
      tabIndex2
    })
    //console.log(this.data.tabIndex2)
  },

  changeTabs3(e) {
    const tabIndex3 = e.currentTarget.dataset.index;
    this.setData({
      tabIndex3
    })
    //console.log(this.data.tabIndex3)
  },

  changeTabs4(e) {
    const tabIndex4 = e.currentTarget.dataset.index;
    this.setData({
      tabIndex4
    })
    //console.log(this.data.tabIndex4)
  },

  initChart1: function () {
    this.echartsComponnet1.init((canvas, width, height,dpr) => {
      // 初始化图表
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      chart.setOption(this.initChart1getOption());
      // 注意这里一定要返回 chart 实例，否则会影响事件处理等
      return chart;
    });
  },

  initChart1getOption: function () {
    var tabIndex = this.data.tabIndex;
    var time = this.data.initChart1dateTimes
    var series = [];
    if(0 == tabIndex){
      series = this.data.initChart1waterStatuss;
    }
    if(1 == tabIndex){
      series = this.data.initChart1ammonias;
    }
    if(2 == tabIndex){
      series = this.data.initChart1permanganateIndexs;
    }
    if(3 == tabIndex){
      series = this.data.initChart1totalPhosphoruss;
    }
    if(4 == tabIndex){
      series = this.data.initChart1totalNitrogens;
    }
    if(5 == tabIndex){
      series = this.data.initChart1phValues;
    }
    var yAxis = {};
    if(0 == tabIndex){
      yAxis = {
        type: 'category',
        boundaryGap: false,
        //分割线
        data: ['Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ', '劣Ⅴ'],
        splitLine: {
          lineStyle: {
            color: '#464A7C',
          }
        },
        // 轴文字样式
        axisLabel: {
          show: true,
          textStyle: {
            color: '#D5D5D7'
          }
        },
      }
    }else{
      yAxis = {
        type: 'value',
        boundaryGap: false,
        axisLabel: {
          show: true,
          textStyle: {
            color: '#D5D5D7'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#464A7C'
          }
        }
      }
    }
    var option = {
      grid: {
        left: '8px',
        right: '8px',
        top: '16px',
        bottom: '0px',
        containLabel: true
      },
      tooltip: {
        trigger: 'item',
        axisPointer: {
          type: 'cross',
        }
      },
      xAxis: {
        type: 'category',
        data: time,
        axisLabel: {
          show: true,
          textStyle: {
            color: '#D5D5D7'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#464A7C'
          }
        }
      },
      yAxis: yAxis,
      series: [{
        data: series,
        type: 'line',
        barWidth: 20 //柱图宽度
      }]
    };
    return option
  },

})